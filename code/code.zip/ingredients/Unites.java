package ingredients;

public enum Unites {
    GRAMME, MILLILITRE
}
