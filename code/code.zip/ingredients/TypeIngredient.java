package ingredients;

public enum TypeIngredient {
    FRUIT, LEGUME, VIANDE, LAITIER, EPICE
}
