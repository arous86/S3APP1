package menufact.plats.Etat;

public class PlatException extends Exception{

}
